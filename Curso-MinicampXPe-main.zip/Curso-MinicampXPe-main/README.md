# Minicamp-XPe 
Exercícios e desafios realizados no primeiro e no segundo módulo do curso.
